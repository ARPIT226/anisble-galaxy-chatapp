# django role

This role manages the django component.
