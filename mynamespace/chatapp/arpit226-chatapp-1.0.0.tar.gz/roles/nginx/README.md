# nginx role

This role manages the nginx component.
