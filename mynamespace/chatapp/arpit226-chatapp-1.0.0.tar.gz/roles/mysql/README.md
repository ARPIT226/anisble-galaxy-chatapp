# mysql role

This role manages the mysql component.
